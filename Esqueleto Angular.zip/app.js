const express = require('express')
const cors = require('cors')
const app = express()

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "YOUR-DOMAIN.TLD"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.use(cors())

app.use(express.static('public'))

const jsonArray = [
    {
        nome:'Marcelo Lindão',
        Idade: 28,
        Observacao:''
    },
    {
        nome:"DelFir",
        Idade:26,
        Observacao:'Não sei se é essa idade'
    },
    {
        nome:"Joiceeeeeeeee",
        Idade: 25,
        Observacao:'Não sei se é essa idade'
    },
    {
        nome:"Tiago sem H",
        Idade:32,
        Observacao:"Melhor agora que estou falando com você (haha)"
    },
    {
        nome:"Ermeso",
        Idade:26,
        Observacao:'Não sei se é essa idade'
    },
    {
        nome:"Carol",
        Idade: 24,
        Observacao:"E aí guri"
    }
]

app.get("/listar", cors(),(req, res)=>{
    res.send(jsonArray)
})

app.listen(4201, ()=>{
    console.log("Rodando na porta 4201")
})